import React, { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';

const HealthMapPreloader = ({ onEnter }) => {
  const overlayRef = useRef(null);
  const containerRef = useRef(null);
  const pulseRefs = useRef([]);
  const [hovered, setHovered] = useState(null);
  const [clicked, setClicked] = useState(false);

  const zones = [
    { id: 'mind', label: 'Mind', sub: 'Mindfulness & Counselling', cx: 210, cy: 72, r: 38, color: '#4EAABD', pulse: '#4EAABD33' },
    { id: 'heart', label: 'Heart', sub: 'Stress Management', cx: 210, cy: 175, r: 28, color: '#E07A5F', pulse: '#E07A5F33' },
    { id: 'core', label: 'Nourish', sub: 'Ayurvedic Diet', cx: 210, cy: 248, r: 26, color: '#81B29A', pulse: '#81B29A33' },
    { id: 'flow', label: 'Flow', sub: 'Yoga & Movement', cx: 210, cy: 318, r: 22, color: '#F2CC8F', pulse: '#F2CC8F33' },
    { id: 'aqua', label: 'Aqua', sub: 'Swimming Therapy', cx: 210, cy: 390, r: 24, color: '#5E8DB5', pulse: '#5E8DB533' },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.preloader-bg-particle', 
        { opacity: 0, scale: 0 }, 
        { opacity: 1, scale: 1, duration: 1.2, stagger: 0.08, ease: 'back.out(1.4)' }
      );
      gsap.fromTo('.preloader-logo', 
        { opacity: 0, y: -30 }, 
        { opacity: 1, y: 0, duration: 1, delay: 0.3, ease: 'power3.out' }
      );
      gsap.fromTo('.preloader-figure', 
        { opacity: 0, y: 40 }, 
        { opacity: 1, y: 0, duration: 1.1, delay: 0.5, ease: 'power3.out' }
      );
      gsap.fromTo('.preloader-hint', 
        { opacity: 0 }, 
        { opacity: 1, duration: 1, delay: 1.8, ease: 'power2.out' }
      );

      gsap.to('.pulse-ring', {
        scale: 2.2,
        opacity: 0,
        duration: 2,
        repeat: -1,
        stagger: { each: 0.4, from: 'random' },
        ease: 'power1.out',
        transformOrigin: 'center center'
      });

      gsap.to('.drift-orb', {
        y: '-=18',
        duration: 3,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
        stagger: 0.5
      });
    }, containerRef);

    return () => ctx.revert();
  }, []);

  const handleEnter = () => {
    if (clicked) return;
    setClicked(true);
    const tl = gsap.timeline({ onComplete: onEnter });
    tl.to('.preloader-hint', { opacity: 0, duration: 0.3 })
      .to('.preloader-figure', { scale: 1.06, duration: 0.4, ease: 'power2.out' })
      .to('.preloader-figure', { scale: 0, opacity: 0, duration: 0.7, ease: 'power3.in' }, '+=0.1')
      .to('.preloader-logo', { opacity: 0, y: -20, duration: 0.5 }, '-=0.4')
      .to(overlayRef.current, { opacity: 0, duration: 0.6, ease: 'power2.inOut' }, '-=0.3');
  };

  return (
    <div
      ref={overlayRef}
      style={{
        position: 'fixed', inset: 0, zIndex: 9999,
        background: 'linear-gradient(135deg, #0f1f2e 0%, #1a3244 40%, #0d2233 100%)',
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        overflow: 'hidden',
        fontFamily: "'Outfit', sans-serif"
      }}
    >
      <div ref={containerRef} style={{ width: '100%', maxWidth: 520, position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>

        {/* Drifting background orbs */}
        {[
          { top: '8%', left: '6%', size: 160, color: '#4EAABD18' },
          { top: '60%', right: '4%', size: 200, color: '#81B29A12' },
          { top: '30%', left: '50%', size: 120, color: '#E07A5F10' },
        ].map((orb, i) => (
          <div key={i} className="drift-orb preloader-bg-particle" style={{
            position: 'absolute', top: orb.top, left: orb.left, right: orb.right,
            width: orb.size, height: orb.size, borderRadius: '50%',
            background: orb.color, filter: 'blur(40px)', pointerEvents: 'none'
          }} />
        ))}

        {/* Logo */}
        <div className="preloader-logo" style={{ textAlign: 'center', marginBottom: 32, position: 'relative', zIndex: 2 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 6 }}>
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
              <path d="M14 3C14 3 6 8 6 15a8 8 0 0016 0c0-7-8-12-8-12z" fill="#4EAABD" opacity="0.9"/>
              <path d="M14 9C14 9 10 12.5 10 16a4 4 0 008 0c0-3.5-4-7-4-7z" fill="#81B29A"/>
            </svg>
            <span style={{ fontSize: 26, fontWeight: 700, color: '#f0f4f8', letterSpacing: '-0.5px' }}>
              Indogulf<span style={{ color: '#4EAABD' }}>wellness</span>
            </span>
          </div>
          <p style={{ fontSize: 12, color: '#6b8fa8', letterSpacing: '3px', textTransform: 'uppercase', margin: 0 }}>
            Holistic Health Journey
          </p>
        </div>

        {/* Health map SVG figure */}
        <div
          className="preloader-figure"
          onClick={handleEnter}
          style={{ cursor: clicked ? 'default' : 'pointer', position: 'relative', zIndex: 2 }}
        >
          <svg width="420" height="480" viewBox="0 0 420 480" fill="none" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <filter id="soft-glow">
                <feGaussianBlur stdDeviation="4" result="blur"/>
                <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
              </filter>
            </defs>

            {/* Body silhouette — stylized abstract human form */}
            {/* Head */}
            <ellipse cx="210" cy="72" rx="42" ry="44" fill="#12293d" stroke="#1d3d56" strokeWidth="1.5"/>
            {/* Neck */}
            <rect x="200" y="110" width="20" height="22" rx="6" fill="#12293d" stroke="#1d3d56" strokeWidth="1"/>
            {/* Torso */}
            <path d="M160 132 C152 138 148 160 150 200 C152 235 155 260 158 278 L262 278 C265 260 268 235 270 200 C272 160 268 138 260 132 Z" fill="#12293d" stroke="#1d3d56" strokeWidth="1.5"/>
            {/* Left arm */}
            <path d="M158 140 C140 148 130 168 128 200 C126 218 128 235 132 245" stroke="#1d3d56" strokeWidth="14" strokeLinecap="round" fill="none"/>
            {/* Right arm */}
            <path d="M262 140 C280 148 290 168 292 200 C294 218 292 235 288 245" stroke="#1d3d56" strokeWidth="14" strokeLinecap="round" fill="none"/>
            {/* Hips */}
            <path d="M158 278 C154 288 152 300 155 315 L265 315 C268 300 266 288 262 278 Z" fill="#12293d" stroke="#1d3d56" strokeWidth="1.5"/>
            {/* Left leg */}
            <path d="M168 315 C164 345 162 370 164 410" stroke="#1d3d56" strokeWidth="18" strokeLinecap="round" fill="none"/>
            {/* Right leg */}
            <path d="M252 315 C256 345 258 370 256 410" stroke="#1d3d56" strokeWidth="18" strokeLinecap="round" fill="none"/>
            {/* Feet */}
            <ellipse cx="163" cy="415" rx="20" ry="9" fill="#12293d" stroke="#1d3d56" strokeWidth="1"/>
            <ellipse cx="257" cy="415" rx="20" ry="9" fill="#12293d" stroke="#1d3d56" strokeWidth="1"/>

            {/* Meridian lines — flowing energy paths */}
            <path d="M210 110 L210 430" stroke="#1d3d5680" strokeWidth="1" strokeDasharray="4 6"/>
            <path d="M180 170 Q210 190 240 170" stroke="#4EAABD30" strokeWidth="1" fill="none"/>
            <path d="M175 230 Q210 250 245 230" stroke="#81B29A30" strokeWidth="1" fill="none"/>

            {/* Connector lines from zones to body */}
            {zones.map((z) => (
              <line
                key={z.id + '-line'}
                x1={z.cx} y1={z.cy}
                x2={z.cx} y2={z.cy}
                stroke={z.color}
                strokeWidth="1"
                opacity="0.4"
              />
            ))}

            {/* Zone pulse rings (animated via CSS class) */}
            {zones.map((z) => (
              <circle
                key={z.id + '-pulse'}
                className="pulse-ring"
                cx={z.cx} cy={z.cy} r={z.r + 10}
                fill="none"
                stroke={z.color}
                strokeWidth="1.5"
                opacity="0.6"
              />
            ))}

            {/* Zone circles — interactive */}
            {zones.map((z) => (
              <g
                key={z.id}
                style={{ cursor: 'pointer' }}
                onMouseEnter={() => setHovered(z.id)}
                onMouseLeave={() => setHovered(null)}
                onClick={handleEnter}
              >
                {/* Glow bg */}
                <circle cx={z.cx} cy={z.cy} r={z.r + 6}
                  fill={z.pulse}
                  opacity={hovered === z.id ? 1 : 0.6}
                  style={{ transition: 'opacity 0.3s' }}
                />
                {/* Main circle */}
                <circle cx={z.cx} cy={z.cy} r={z.r}
                  fill={z.color}
                  opacity={hovered === z.id ? 1 : 0.85}
                  style={{ transition: 'all 0.3s', transform: hovered === z.id ? `scale(1.12)` : 'scale(1)', transformOrigin: `${z.cx}px ${z.cy}px` }}
                />
                {/* Label */}
                <text x={z.cx} y={z.cy + 1} textAnchor="middle" dominantBaseline="middle"
                  fill="white" fontSize="11" fontWeight="600" fontFamily="Outfit, sans-serif"
                  style={{ pointerEvents: 'none', letterSpacing: '0.5px' }}
                >
                  {z.label}
                </text>

                {/* Tooltip on hover */}
                {hovered === z.id && (
                  <g>
                    <rect
                      x={z.cx + z.r + 10} y={z.cy - 18}
                      width={120} height={34}
                      rx="6" fill="#0d2233" stroke={z.color} strokeWidth="1"
                    />
                    <text x={z.cx + z.r + 70} y={z.cy - 4}
                      textAnchor="middle" fill={z.color}
                      fontSize="10" fontWeight="600" fontFamily="Outfit, sans-serif"
                    >
                      {z.label}
                    </text>
                    <text x={z.cx + z.r + 70} y={z.cy + 10}
                      textAnchor="middle" fill="#8ab0c8"
                      fontSize="9" fontFamily="Outfit, sans-serif"
                    >
                      {z.sub}
                    </text>
                  </g>
                )}
              </g>
            ))}

            {/* Center vertical energy line */}
            <line x1="210" y1="116" x2="210" y2="405"
              stroke="url(#energyGrad)" strokeWidth="1.5" strokeDasharray="3 8" opacity="0.35"/>
            <defs>
              <linearGradient id="energyGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#4EAABD"/>
                <stop offset="50%" stopColor="#81B29A"/>
                <stop offset="100%" stopColor="#5E8DB5"/>
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* CTA hint */}
        <div className="preloader-hint" style={{ textAlign: 'center', marginTop: 8, position: 'relative', zIndex: 2 }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 10,
            padding: '10px 24px', borderRadius: 40,
            border: '1px solid #4EAABD50',
            background: '#4EAABD10',
            color: '#8dd0de',
            fontSize: 13, letterSpacing: '0.5px',
            animation: 'breathe 2.5s ease-in-out infinite'
          }}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <circle cx="7" cy="7" r="6" stroke="#4EAABD" strokeWidth="1.2"/>
              <path d="M5 7l2 2 3-3" stroke="#4EAABD" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Tap your health map to begin
          </div>
        </div>

        <style>{`
          @keyframes breathe {
            0%, 100% { opacity: 0.7; transform: scale(1); }
            50% { opacity: 1; transform: scale(1.03); }
          }
        `}</style>
      </div>
    </div>
  );
};

export default HealthMapPreloader;
